from twitter import *
import simplejson
import time
import RPi.GPIO as GPIO

turl = 'http://api.twitter.com/1.1/search/tweets.json?q='
CONSUMER_KEY = 'TORel1q2wlFbuxuUK3Kfg'
CONSUMER_SECRET = 'mcWQaXt6u8D0X7ygsuAnl5YwUqEUU4okCRfGLIJXg0'
OAUTH_TOKEN = '38333739-xnoBMgmE7Bj0q0WBSMLT2VJ6DuOKw0qzbMsCM5qel'
OAUTH_SECRET = '6LnXPSIocLK48VCMwRdGre1y9UpnjXrPAOwUxhvk'


t = TwitterStream( auth=OAuth(OAUTH_TOKEN,OAUTH_SECRET,CONSUMER_KEY,CONSUMER_SECRET) )
iterator = t.statuses.sample()

for tweet in iterator:
  print tweet


