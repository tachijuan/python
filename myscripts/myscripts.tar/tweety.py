from twitter import *
import simplejson
import time
import RPi.GPIO as GPIO

GPIO.cleanup()
GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)


turl = 'http://api.twitter.com/1.1/search/tweets.json?q='
CONSUMER_KEY = 'TORel1q2wlFbuxuUK3Kfg'
CONSUMER_SECRET = 'mcWQaXt6u8D0X7ygsuAnl5YwUqEUU4okCRfGLIJXg0'
OAUTH_TOKEN = '38333739-xnoBMgmE7Bj0q0WBSMLT2VJ6DuOKw0qzbMsCM5qel'
OAUTH_SECRET = '6LnXPSIocLK48VCMwRdGre1y9UpnjXrPAOwUxhvk'


t = Twitter( auth=OAuth(OAUTH_TOKEN,OAUTH_SECRET,CONSUMER_KEY,CONSUMER_SECRET) )

try:
  while True:
    twitter_results = t.statuses.home_timeline()
    tweet = twitter_results[0]['text']

    if 'ON' in tweet:
      print "LED Turned ON"
      GPIO.output(7,GPIO.HIGH)

    if "OFF" in tweet:
      print "LED turned OFF"
      GPIO.output(7,GPIO.LOW)

    time.sleep(10)

except KeyboardInterrupt:
  print "Exiting now!"
  GPIO.cleanup()


